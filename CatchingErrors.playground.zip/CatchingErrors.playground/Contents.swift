import UIKit


enum RegistrationDetailsFormatError : Error{
    
    case usernameEmpty
    case passwordEmpty
    case passwordShort
    
    
    
}


func validateUserDetails(username : String, password: String) throws{
    
    if username.isEmpty{
        
        throw RegistrationDetailsFormatError.userNameEmpty
        
    }
    else if password.isEmpty{
        
        throw RegistrationDetailsFormatError.passwordEmpty
        
        
    }else if password.count < 7{
        
        throw RegistrationDetailsFormatError.passwordShort
        
    }
    
}
do{
    
    try validateUserDetails(username: "Stephan", password : "k233453")
    
    print("Validation success message")
    
    
    
}
catch  RegistrationDetailsFormatError.userNameEmpty,RegistrationDetailsFormatError.passwordEmpty{
    
    print("Password and Username details are a must")
    
    
}
catch RegistrationDetailsFormatError.passwordShort{
    
    
    print("Password too short")

}
//general catch block
catch{
    
    print(error)
    
}

