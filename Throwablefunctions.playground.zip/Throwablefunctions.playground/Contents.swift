import UIKit

enum  PasswordValidationError: Error {
    
    case passwordShort
    
    
}

func validatePassword(password  : String) throws {
    
    if password.count <= 6{
        
        throw PasswordValidationError.passwordShort
        
        
        
    }
    
    
}
