import UIKit

var numbers = [2, 9, 0,2, 8]

var newNames = Array(repeating: 8, count: 5)

var combination = numbers + newNames

print(numbers[2])
print(numbers.count)

for i in 0..<numbers.count{
    
    print(numbers[i])
    
    
}
numbers.append(9)

print(numbers.count)

print(newNames.count)
print(combination.count)

numbers += [5]

print(numbers.count)

for (index, value) in newNames.enumerated(){
    
    print("\(index) : \(value)" )
    
}



// Any array


var anArray:[Any] = [59]
anArray.append(3.33)
anArray.append("Orange")

print(anArray)



// tuples

var myFirstTuple = ("Kato", 1996, 80.0)

var (name, year , mark) = myFirstTuple

print(year)

var mySecondTuple = (name2 : "Steven" , month : 5 , numbers : 10)

print(mySecondTuple.month)


// exercise

let credentials = (password: "" , passcode : -1111)

if((credentials.password == "") || (credentials.passcode > 0 )){
    
    print("Invalid Credentials")
    
}
else{
    
    print("Password is valid.")
}

// Dictionaries

var ageMates : Dictionary<String, Int>

 ageMates = ["Kato" : 12, "Steven" : 13 ]
                
                print(ageMates.count)
print(ageMates)

ageMates["Mubiru"] = 21
print(ageMates.count)

// to retrieve , we need an if let.

if let myFirstAge = ageMates["Kato"]{
    print(myFirstAge)
}
// declaring an empty dictionary

var weeklyTemperatures : [String: Int] = [:]

// using the for each to attain values in a dictionary
for (nam , ag) in ageMates{
    
    print("Hello \(nam) and age is \(ag)")
    
}
print(ageMates.keys)
