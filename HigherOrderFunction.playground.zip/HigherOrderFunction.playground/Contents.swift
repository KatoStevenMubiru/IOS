import UIKit

let originalPrices = [2, 5, 6, 4 , 3 , 1]

func convertPrices(originalPrices: [Int], conversionClosure: (_ price : Int)-> Int) -> [Int]{
    
    var convertedPrices = [Int]()
    for originalPrice in originalPrices {
        
        let convertedPrice = conversionClosure(originalPrice)
        
        convertedPrices.append(convertedPrice)
    }
    
    
    return convertedPrices
    
    
}

convertPrices(originalPrices:originalPrices, conversionClosure: { $0 * 2 } )
