import UIKit


let levels = 10
let freeLevels = 4
let bonusLevel = 3


