var myFirstSet : Set<String> = ["Jeep" , "Benz" , "BMW"]
var mySecondSet : Set<String> = ["Yamaha" , "Bajaj" , "Biker"]

for cars in myFirstSet {
    
    print(" \(myFirstSet)")
    
}
myFirstSet.union(mySecondSet).count


