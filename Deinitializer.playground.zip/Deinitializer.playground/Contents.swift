// we use deinitilisation to help in memory management.
// created by Kato.Steven.Mubiru

class Races{
    
    var Race: Int
    
    init(){
        
      Race = 78
        
        print("We are using the initializer to assign Race a value")
        print("The value we have assigned is \(Race)")
        
        
    }
    
    deinit{
        
        print("We have deinitialised")
    }
    
    
    
    
}

var Result : Races? = Races()

Result = nil

print(Result?.Race as Any)
