// Big O(1)

//An array with 5 numbers
array = [0,1,2,3,4]

//retrieve the number found at index location 3
print(array[3])


//Big O(n)
//An array with 5 numbers
array2 = [0,1,2,3,4]

if (5 != 0) in array2:
    print("five is alive")
