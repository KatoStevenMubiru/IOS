// SETS in swift

var colors : Set<String> = ["purple", "yellow", "green"]
var food : Set<String> = ["pasta", "meat", "chicken"]

//add an element

colors.insert("blue")

print(colors)

// remove and element

colors.remove("yellow")

print(colors)

// add the same element and print

colors.insert("blue")

print(colors)

// count the elements in an array to see

print(colors.count)

var unionofthetwosets = colors.union(food)

//print the union

print(unionofthetwosets)


