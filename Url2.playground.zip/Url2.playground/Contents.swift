//task 2
import Foundation




let url2 = URL(string: " www.google.com ")
let request2 = URLRequest(url: url2!)
URLSession.shared.dataTask(with: request2) { _, _, _ in
 print("Task completed")
}
print("Task created")
