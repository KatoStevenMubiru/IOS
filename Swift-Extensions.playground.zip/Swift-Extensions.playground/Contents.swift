// we can add functionality to a class, method etc while using the extensions.

import UIKit

class Temperature{
    
    var celcius: Double = 0
    
    func setTemperature(celcius : Double){
        
        self.celcius = celcius
        
        print("The Celcius is" , celcius)
        
    }
    
    
    
}
// here we extend the class

extension Temperature{
    
    func convert(){
        
        var farn = (celcius * 1.8) + 32
        print("Fahrenheit : ", farn)
        
    }
    
    
}
// creating an object out of the class temperature
let temp1 = Temperature()

temp1.setTemperature(celcius: 9.7)

temp1.convert()

