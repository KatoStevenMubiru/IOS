import UIKit

var num = 9
repeat{
    
    print("num is less than 9")
}
while num <= 9




        
        

