import UIKit

let paymentsArray = [99.54, 44.31, 89.0, 6.5, 21.24, 63.7, 59.2]


let largePayments = paymentsArray.filter { $0  > 60 }

print(largePayments)


let filteredPayStrings = largePayments.map{ String( $0 ) }

print(filteredPayStrings)

let finalReduced = filteredPayStrings.reduce(",") { $0 + $1}

print(finalReduced)

class Berry {
}
class Blueberry: Berry {
}
class Strawberry: Berry {
}
let berries = [Berry(), Blueberry(), Strawberry()]
for berry in berries {
    if berry is Berry {
        print("Berry")
    }
    if berry is Blueberry {
        print("Blueberry")
    }
    if berry is Strawberry {
        print("Strawberry")
    }
}
