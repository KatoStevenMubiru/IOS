class Subject{
    
    var physics: String
    
    init(physics : String){
        
        self.physics = physics
    }
    
    
}

class Chemistry : Subjects{
    
    var equations : String
    
    init(physics: String, equation : String){
        
        self.equations = equations
        super.init(physics : physics)
        
        
    }
    
    
    
}
class Maths : Subjects{
    
    var formulae : String
    
    init(physics : String, formulae : String){
        
        self.formulae = formulae
        
        super.init(physics : physics)
        
        
        
    }
    
}

let sa = [ Chemistry(physics : " Solid physics", equation : "Hertz")]
