class Spaghetti{
    
    var ingredients: Set<String> = [
    "pasta",
    "tomato sauce"
    
    ]
    
    func fectching(){
    
        print("Special spaghetti meatball ingredients")
        print("The ingredients are \(ingredients)")
    }
    
    
    
}

class Meatball: Spaghetti{
    
    override func fectching() {
        print("Am over ridding the ingredients")
    }
    
}
let Spags1 = Spaghetti()

let Spags2 = Meatball()

Spags1.fectching()
Spags2.fectching()


// exercise
class Dish {
    private let name: String
    private var ingredients: [String]
    init(name: String, ingredients: [String]) {
        self.name = name
        self.ingredients = ingredients
    }
    func printInfo() {
        print(name)
        print(ingredients)
    }
}
